graph TD

    subgraph "ESQUEMA SÍLABAS"
        A[Letras]
        B[Palabras]
        C[Sílabas]
        D[Monosílabos]
        E[Polisílabos]
        F[Dígrafos]
    end

    A -->|Forman| B
    A -->|El conjunto de letras forma| B
    B -->|Según el número de sílabas| D
    B -->|Según el número de sílabas| E
    B -->|Se pronuncian a golpe de voz| C
    C -->|Para separar, se debe tener en cuenta| F

---
marp: true
---

# Estructuras condicionales y bucles en Python3

---

## Introducción

- En programación, las estructuras condicionales y bucles son fundamentales.
- Permiten controlar el flujo de ejecución del programa.
- En Python3, tenemos varias construcciones para implementar estas estructuras.

---

## Estructuras Condicionales

### If-else

```python
if condicion:
    # Bloque de código si la condición es verdadera
else:
    # Bloque de código si la condición es falsa
```

### Elif

```python
if condicion1:
    # Bloque de código si la condición1 es verdadera
elif condicion2:
    # Bloque de código si la condición2 es verdadera
else:
    # Bloque de código si ninguna condición es verdadera
```

---

## Bucles (Loops)

### Bucle While

```python
while condicion:
    # Bloque de código ejecutado mientras la condición sea verdadera
```

### Bucle For

#### Iterando sobre una secuencia

```python
for elemento in secuencia:
    # Bloque de código ejecutado para cada elemento en la secuencia
```

#### Range

```python
for i in range(inicio, fin, paso):
    # Bloque de código ejecutado para i en el rango [inicio, fin) con paso
```

---

## Ejemplos Prácticos

### Estructuras Condicionales

```python
edad = 18

if edad >= 18:
    print("Eres mayor de edad")
else:
    print("Eres menor de edad")
```

### Bucles

```python
# Imprimir los números del 1 al 5 usando un bucle for
for i in range(1, 6):
    print(i)
```

---

## Conclusiones

- Las estructuras condicionales y bucles son esenciales en programación.
- En Python3, se utilizan `if-else`, `elif` para estructuras condicionales y `while`, `for` para bucles.

---

## ¡Gracias!

- ¿Preguntas?

@Sergi García

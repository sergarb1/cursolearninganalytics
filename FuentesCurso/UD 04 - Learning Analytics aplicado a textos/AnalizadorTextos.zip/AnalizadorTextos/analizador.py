#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#Bibliotecas necesarias para el funcionamiento del programa
import sys
import re 
import string
import unicodedata
import collections

# Para los PDFs, necesario pip install pdfminer y pip install pdfminer.six
from pdfminer.high_level import extract_text

#Funcion que convierte un PDF del cual se proporciona la ruta a texto
def convert_pdf_to_txt(path):
    text = extract_text(path)
    #Eliminamos lineas vacias
    text = "\n".join([s for s in text.splitlines() if s.lower()!=s.upper()])
    return preprocesarPalabra(text)

# Funcion para eliminar acentos en el proceso de normalizacion del texto
def strip_accents(input):
    '''
    Accept a unicode string, and return a normal string (bytes in Python 3)
    without any diacritical marks.
    '''
    return unicodedata.normalize('NFKD', input).encode('ASCII', 'ignore').decode()


#Funcion que preprocesa una palabra para facilitar su normalizacion en el analisis
def preprocesarPalabra(pal):
  #Pasamos a mayuscula
  pal = pal.upper().strip()
  #Eliminamos acentos
  pal = strip_accents(pal)

  return pal


#Definimos algunas variables que utilizaremos durante el programa
stopwords = []
linea_actual = 0
sentencias_ideales_ordenadas = []
resumen_texto = []
texto_bruto=""

# Apertura del archivo "stopwords-español.txt" el cual contiene las stopwords
# mismas que son almacenadas en el array stopwords

with open('stopwords-espanol.txt',encoding="utf-8") as f:
    stopwords = f.read().splitlines()

#Preprocesamos cada stopword
for i in range(len(stopwords)):
  stopwords[i]=preprocesarPalabra(stopwords[i])

# Apertura del archivo de texto que se paso como argumento al ejecutar la aplicación

#Si hay 2 argumentos y el segundo es PDF, es que debemos tratarlo como fichero PF
if len(sys.argv)>2 and sys.argv[2].upper()=="PDF":
  ## informacion https://www.soudegesu.com/en/post/python/extract-text-from-pdf-with-pypdf2/
  texto_bruto=convert_pdf_to_txt(sys.argv[1])
 
  lineas =texto_bruto.splitlines()

#Si solo hay un argumento, tratamos le fichero como texto directamente.
else:
  with open(sys.argv[1],encoding="utf-8") as f:
    texto_bruto=f.read()
    #Eliminamos lineas vacias
    texto = "\n".join([s for s in texto_bruto.splitlines() if s.lower()!=s.upper()])
    lineas =texto.splitlines()
    
    #Eliminamos lineas vacias


#Preprocesamos cada linea
for i in range(len(lineas)):
  lineas[i]=preprocesarPalabra(lineas[i])

# Conteo de las lineas del archivo

contador_lineas = len(lineas)

# Unión de todas las cadenas contenidas en el array "lineas"

texto = "".join(lineas)

# Conteo de caracteres

contador_caracteres = len(texto)
contador_caracteres_sin_espacios=len(re.sub(r"\s+", "", texto))



# Conteo de palabras, sentencias, y párrafos

contador_palabras = len(texto.split(" "))
contador_sentencias = len(re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', texto))
contador_parrafos = len(texto_bruto.split("\n\n"))




# Crea un listado de palabras en el texto que no son stopwords
# contandolas, y calculando el porcentaje de palabras relevantes
# contra el total de palabras

total_de_palabras = re.sub('['+string.punctuation+']', ' ', texto).split(" ")
palabras_adecuadas=[]

for pal in total_de_palabras:
  if pal not in stopwords:
    palabras_adecuadas.append(pal)

# Calculamos porcentaje relevante de palabras del texot
porcentaje_relevante = (len(palabras_adecuadas) / len(total_de_palabras) * 100)


# Obtenemos la frecuencia de aparacion de palabras en el texto
wordfreq = []
usadas=[]
for w in palabras_adecuadas :
  if(len(w)>0 and w not in usadas):
    usadas.append(w)
    wordfreq.append([w,palabras_adecuadas.count(w)])

wordfreq=sorted(wordfreq, key = lambda x: x[1],reverse=True)


# Resumen del texto por medio de la selección de algunas sentencias

sentencias=re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', texto)

#Ordenamos sentencias por tamanyo
sentencias_ordenadas = sorted(sentencias, key=len) 

tercio = int( len(sentencias_ordenadas) / 3)
#cogemos el primer tercio
sentencias_ideales = sentencias_ordenadas[:tercio + 1]


sentencias_ideales_filtradas=[]
#Filtramos que tengan definiciones con ES SON ESTA ESTAN
for s in sentencias_ideales:
  if " ES " in s or " SON " in s or " ESTA " in s or " ESTAN " in s:
    sentencias_ideales_filtradas.append(s)


## Obtenemos la posiciones de las "sentencias_ideales" dentro del array "sentencias"
## para posteriormente almacenar dichas posiciones en el array "sentencias_ideales_ordenadas"

#Primero entre las filtradas
sentencias_ideales_filtradas_ordenadas=[]

for i in range(len(sentencias)):
  for s in sentencias_ideales_filtradas:
    if s in sentencias[i]:
      sentencias_ideales_filtradas_ordenadas.append(sentencias[i])
      break


#Segundo sin filtrar
sentencias_ideales_ordenadas=[]

for i in range(len(sentencias)):
  for s in sentencias_ideales:
    if s in sentencias[i]:
      sentencias_ideales_ordenadas.append(sentencias[i])
      break


# Muestra al usuario el resultado del análisis del texto
print ("\n\nFrases relevantes del texto:\n\n" + "\n".join(sentencias_ideales_ordenadas))
print( "\n\n-- Fin del análisis. --\n\n")

print( "Frecuencia de palabras:\n\n")

for x in wordfreq:
  print("Palabra: '"+x[0]+"' Frecuencia: "+str(x[1]))

print( "Estadísticas del texto:\n\n")
print( str(contador_lineas) + " lineas")
print( str(contador_caracteres) + " caracteres")
print( str(contador_caracteres_sin_espacios) + " caracteres (excluyendo espacios)")
print( str(contador_palabras) + " palabras")
print( str(contador_sentencias) + " sentencias")
print( str(contador_parrafos) + " párrafos")
print( str(contador_sentencias / contador_parrafos) + " sentencias por párrafo (promedio)")
print( str(contador_palabras / contador_sentencias) + " palabras por sentencia (promedio)")
print( str(porcentaje_relevante) + " % de palabras relevantes")


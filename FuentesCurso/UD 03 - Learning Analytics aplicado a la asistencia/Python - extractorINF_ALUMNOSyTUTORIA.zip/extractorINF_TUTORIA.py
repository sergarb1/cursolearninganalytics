# Usamos la biblioteca Python Tabula
# Se puede instalar con "pip install tabula-py"
# Documentacion https://tabula-py.readthedocs.io/en/latest/
import tabula
import csv

# Convertirmos el PDF generado por ITACA en un CSV
tabula.convert_into("INF_TUTORIA.pdf", "INF_TUTORIA_bruto.csv",
                    output_format="csv",  pages="all")


# Procesamos ligeramente el CSV para mejorar su uso
# Simplemente vamos a duplicar el nombre de alumno en cada fila que se le asocie


salidarProcesada = []
salidarProcesadaAnonimizada = []

with open('INF_TUTORIA_bruto.csv', newline='') as csvfile:
    ficheroCSV = csv.reader(csvfile, delimiter=',', quotechar='"')
    empieza = False
    nombreAlumno = "ALUMNO"
    nAlumno=1
    for row in ficheroCSV:
        rowAnonima=row[:]
        if(row[0] == "Apellidos y Nombre"):
            # Detectamos que empiezan los alumnos
            empieza = True
            salidarProcesada.append(row)
            salidarProcesadaAnonimizada.append(row)
        elif(empieza == True):
            rowAnonima[0]=nombreAlumno+str(nAlumno)
            nAlumno=nAlumno+1
            if(row[2]=="TOTAL"):
                break
            salidarProcesada.append(row)
            salidarProcesadaAnonimizada.append(rowAnonima)

        
        elif(empieza == False):
            salidarProcesada.append(row)
            salidarProcesadaAnonimizada.append(row)

with open('INF_TUTORIA_procesado.csv', 'w', newline='') as csvfile:
    ficheroNoAnonimo = csv.writer(csvfile, delimiter=',',
                            quotechar='"', quoting=csv.QUOTE_MINIMAL)
    for r in salidarProcesada:
        ficheroNoAnonimo.writerow(r)



# ANONIMIZADO
with open('INF_TUTORIA_anonimizado.csv', 'w', newline='') as csvfile:
    ficheroAnonimo = csv.writer(csvfile, delimiter=',',
                            quotechar='"', quoting=csv.QUOTE_MINIMAL)
    for r in salidarProcesadaAnonimizada:
        ficheroAnonimo.writerow(r)
# Usamos la biblioteca Python Tabula
# Se puede instalar con "pip install tabula-py". Tabula además requiere Java
# Documentacion https://tabula-py.readthedocs.io/en/latest/
import tabula
import csv

# Convertirmos el PDF generado por ITACA en un CSV
tabula.convert_into("INF_ALUMNOS.pdf", "INF_ALUMNOS_bruto.csv",
                    output_format="csv",  pages="all")


# Procesamos ligeramente el CSV para mejorar su uso
# Simplemente vamos a duplicar el nombre de alumno en cada fila que se le asocie
salidarProcesada = []

with open('INF_ALUMNOS_bruto.csv', newline='', encoding="utf8") as csvfile:
    ficheroCSV = csv.reader(csvfile, delimiter=',', quotechar='"')
    empieza = False
    nombreAlumno = ""
    for row in ficheroCSV:
        if(row[0] == "Alumno"):
            # Detectamos que empiezan los alumnos
            empieza = True
        elif(empieza == True):
            # Caso de mismo alumno, segunda pagina, no hacer nada
            if(row[0] == ""):
                row[0] = nombreAlumno
                empieza = False
            else:
                nombreAlumno = row[0]
                empieza = False
        elif(row[0] == ""):
            row[0] = nombreAlumno

        #print(', '.join(row))

        salidarProcesada.append(row)

with open('INF_ALUMNOS_procesado.csv', 'w', newline='', encoding="utf8") as csvfile:
    ficheroNoAnonimo = csv.writer(csvfile, delimiter=',',
                            quotechar='"', quoting=csv.QUOTE_MINIMAL)
    for r in salidarProcesada:
        ficheroNoAnonimo.writerow(r)



# ANONIMIZADO

# Procesamos ligeramente el CSV para mejorar su uso
# Simplemente vamos a duplicar el nombre de alumno en cada fila que se le asocie


salidarProcesadaAnonimizada = []

with open('INF_ALUMNOS_bruto.csv', newline='', encoding="utf8") as csvfile:
    ficheroCSV = csv.reader(csvfile, delimiter=',', quotechar='"')
    empieza = False
    nombreAlumno = "ALUMNO"
    nAlumno=0
    for row in ficheroCSV:
        if(row[0] == "Alumno"):
            # Detectamos que empiezan los alumnos
            empieza = True
        elif(empieza == True):
            # Caso de mismo alumno, segunda pagina, no hacer nada
            if(row[0] == ""):
                row[0] = nombreAlumno + str(nAlumno)
                empieza = False
            else:
                nAlumno=nAlumno+1
                
                row[0] = nombreAlumno + str(nAlumno)
                empieza = False
        elif(row[0] == ""):
            row[0] = nombreAlumno + str(nAlumno)

        #print(', '.join(row))

        salidarProcesadaAnonimizada.append(row)

with open('INF_ALUMNOS_anonimizado.csv', 'w', newline='') as csvfile:
    ficheroAnonimizado = csv.writer(csvfile, delimiter=',',
                            quotechar='"', quoting=csv.QUOTE_MINIMAL)
    for r in salidarProcesadaAnonimizada:
        ficheroAnonimizado.writerow(r)
